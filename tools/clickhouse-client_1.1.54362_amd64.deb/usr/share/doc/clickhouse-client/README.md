ClickHouse is an open-source column-oriented database management system that allows generating analytical data reports in real time.

[Read more...](https://clickhouse.yandex/)

[![Build Status](https://travis-ci.org/yandex/ClickHouse.svg?branch=master)](https://travis-ci.org/yandex/ClickHouse)
